"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9580],{99580:(e,l,r)=>{r.r(l),r.d(l,{arrowBottomSvg:()=>o});var a=r(46797);let o=(0,a.JW)`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M7 1.99a1 1 0 0 1 1 1v7.58l2.46-2.46a1 1 0 0 1 1.41 1.42L7.7 13.69a1 1 0 0 1-1.41 0L2.12 9.53A1 1 0 0 1 3.54 8.1L6 10.57V3a1 1 0 0 1 1-1Z"
    clip-rule="evenodd"
  />
</svg>`}}]);